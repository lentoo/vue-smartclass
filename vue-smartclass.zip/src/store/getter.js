export default {
    filtersClass: (state) => {
        return state.classFilter;
    },
    BuildingName: (state) => {
        return state.BuildingName;
    },
    layerName: (state) => {
        return state.layerName;
    }
}